<h1>Selamat Datang</h1>
<h2><?=  $this->session->userdata('nama') ?></h2>