<!DOCTYPE html>

<!-- =========================================================
* Sneat - Bootstrap 5 HTML Admin Template - Pro | v1.0.0
==============================================================

* Product Page: https://themeselection.com/products/sneat-bootstrap-html-admin-template/
* Created by: ThemeSelection
* License: You must have a valid license purchased in order to legally use the theme for your project.
* Copyright ThemeSelection (https://themeselection.com)

========================================================= -->
<html
  lang="en"
  class="dark-style customizer-hide"
  dir="ltr"
  data-theme="theme-dark"
  data-assets-path="<?= site_url('assets/sneat') ?>/assets/"
  data-template="vertical-menu-template-free"
>
  <head>
    <meta charset="utf-8" />
    <meta
      name="viewport"
      content="width=device-width, initial-scale=1.0, user-scalable=no, minimum-scale=1.0, maximum-scale=1.0"
    />

    <title>Login</title>

    <link rel="icon" type="image/x-icon" href="<?= site_url('assets/sneat') ?>/assets/img/favicon/favicon.ico" />

    <!-- Fonts -->
    <link rel="preconnect" href="https://fonts.googleapis.com" />
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin />
    <link
      href="https://fonts.googleapis.com/css2?family=Public+Sans:ital,wght@0,300;0,400;0,500;0,600;0,700;1,300;1,400;1,500;1,600;1,700&display=swap"
      rel="stylesheet"
    />

    <!-- Icons. Uncomment required icon fonts -->
    <link rel="stylesheet" href="<?= site_url('assets/sneat') ?>/assets/vendor/fonts/boxicons.css" />

    <!-- Core CSS -->
    <link rel="stylesheet" href="<?= site_url('assets/sneat') ?>/assets/vendor/css/core.css" class="template-customizer-core-css" />
    <link rel="stylesheet" href="<?= site_url('assets/sneat') ?>/assets/vendor/css/theme-default.css" class="template-customizer-theme-css" />
    <link rel="stylesheet" href="<?= site_url('assets/sneat') ?>/assets/css/demo.css" />

    <!-- Vendors CSS -->
    <link rel="stylesheet" href="<?= site_url('assets/sneat') ?>/assets/vendor/libs/perfect-scrollbar/perfect-scrollbar.css" />

    <!-- Page CSS -->
    <link rel="stylesheet" href="<?= site_url('assets/sneat') ?>/assets/vendor/css/pages/page-auth.css" />
    
    <!-- Dark Theme Styles -->
    <style>
      :root {
        --bs-body-bg: #2b2c40;
        --bs-body-color: #a3a4cc;
      }
      
      body {
        background-color: #2b2c40 !important;
        color: #a3a4cc;
      }

      .authentication-wrapper {
        background-color: #2b2c40;
      }

      .card {
        background-color: #2f3349 !important;
        border: 1px solid #444564;
      }

      .card-body {
        color: #a3a4cc;
      }

      h4, .h4 {
        color: #cbcbe2 !important;
      }

      .form-label {
        color: #a3a4cc;
      }

      .form-control,
      .form-select,
      .input-group-text {
        background-color: #2b2c40 !important;
        border-color: #444564 !important;
        color: #a3a4cc !important;
      }

      .form-control:focus,
      .form-select:focus {
        background-color: #2b2c40;
        border-color: #696cff !important;
        color: #a3a4cc;
      }

      .input-group-text {
        color: #a3a4cc !important;
      }

      .input-group-merge .form-control:not(:last-child) {
        border-right: 0 !important;
      }

      .btn-primary {
        background-color: #696cff !important;
        border-color: #696cff !important;
      }

      .btn-primary:hover {
        background-color: #5f65e5 !important;
        border-color: #5f65e5 !important;
      }

      .authentication-basic {
        background-color: transparent !important;
      }

      .text-muted {
        color: #7071a4 !important;
      }

      ::placeholder {
        color: #7071a4 !important;
        opacity: 0.5;
      }
    </style>
  </head>

  <body>
    <div class="container-xxl">
      <div class="authentication-wrapper authentication-basic container-p-y">
        <div class="authentication-inner">
          <div class="card">
            <div class="card-body">
              <h4 class="mb-2">Welcome to CMS! 👋</h4>
              <?php if ($this->session->flashdata('alert')): ?>
                  <?php echo $this->session->flashdata('alert'); ?>
              <?php endif; ?>
              <form action="<?php echo site_url('auth/register'); ?>" method="post">
                  <div class="mb-3">
                      <label for="nama" class="form-label">Name</label>
                      <input type="text" class="form-control" id="nama" name="nama" required autocomplete="name">
                  </div>
                  <div class="mb-3">
                      <label for="username" class="form-label">Username</label>
                      <input type="text" class="form-control" id="username" name="username" required autocomplete="username">
                  </div>
                  <div class="mb-3">
                      <label for="password" class="form-label">Password</label>
                      <input type="password" class="form-control" id="password" name="password" required autocomplete="new-password">
                  </div>
                  <input type="hidden" name="level" value="user"> <!-- Default user level -->
                  <button type="submit" class="btn btn-primary d-grid w-100">Register</button>
              </form>
              <div class="mt-3">
                  <p class="text-center">
                      Already have an account? <a href="<?= site_url('auth') ?>">Login here</a>
                  </p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>

    <!-- Core JS -->
    <!-- build:js assets/vendor/js/core.js -->
    <script src="<?= site_url('assets/sneat') ?>/assets/vendor/libs/jquery/jquery.js"></script>
    <script src="<?= site_url('assets/sneat') ?>/assets/vendor/libs/popper/popper.js"></script>
    <script src="<?= site_url('assets/sneat') ?>/assets/vendor/js/bootstrap.js"></script>
    <script src="<?= site_url('assets/sneat') ?>/assets/vendor/libs/perfect-scrollbar/perfect-scrollbar.js"></script>

    <script src="<?= site_url('assets/sneat') ?>/assets/vendor/js/menu.js"></script>
    <!-- endbuild -->

    <!-- Main JS -->
    <script src="<?= site_url('assets/sneat') ?>/assets/js/main.js"></script>
  </body>
</html>
